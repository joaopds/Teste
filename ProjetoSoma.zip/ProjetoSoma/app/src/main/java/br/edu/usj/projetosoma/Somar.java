package br.edu.usj.projetosoma;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Somar extends AppCompatActivity {
    private TextView mostrarSomaTextView;
    public static final String EXTRA_NOME =
            "ProjetoSoma.Somar.extra_nome";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_soma);
        this.mostrarSomaTextView = (TextView) findViewById(R.id.mostrarSomaTextView);

        Intent intent = getIntent();
        if(intent.hasExtra(EXTRA_NOME)){
            String valor = intent.getStringExtra(EXTRA_NOME);
            this.mostrarSomaTextView.setText(valor);
        }
        else{
            this.mostrarSomaTextView.setText("sem informação");
        }

    }


}
