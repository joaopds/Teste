package br.edu.usj.projetosoma;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText valor1EditText,valor2EditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.valor1EditText = (EditText)findViewById(R.id.valor1EditText);
        this.valor2EditText = (EditText)findViewById(R.id.valor2EditText);
        Intent intent = getIntent();
    }
    public void FazerCalculo(View view){
        Editable textoEditable1 = this.valor1EditText.getText();
        Editable textoEditable2 = this.valor2EditText.getText();
        int valor1 = Integer.parseInt(textoEditable1.toString());
        int valor2 = Integer.parseInt(textoEditable2.toString());
        Integer soma = valor1 + valor2;

        Intent intent = new Intent(this, Somar.class);
        intent.putExtra(Somar.EXTRA_NOME,
                soma.toString());
        startActivity(intent);

    }

}
